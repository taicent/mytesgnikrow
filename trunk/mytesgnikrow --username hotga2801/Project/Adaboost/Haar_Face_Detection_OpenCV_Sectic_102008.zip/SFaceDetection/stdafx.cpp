/*
---- Author : Binh Nguyen - Bioz
---- Last Update : 21 Oct 2008	 
---- License : Free
---- Official site : www.sectic.com
---- Description : detect face by using haar model supplied by OpenCV lib. 
*/
// stdafx.cpp : source file that includes just the standard includes
// FaceDetection.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"


