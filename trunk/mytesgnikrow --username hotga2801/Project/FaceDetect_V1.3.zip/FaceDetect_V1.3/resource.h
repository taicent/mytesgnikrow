//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FaceDetect.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_FACEDETYPE                  129
#define IDD_Option                      134
#define IDC_RADIO1                      1013
#define IDC_AdaBoost                    1013
#define IDC_RADIO2                      1014
#define IDC_FFS                         1014
#define IDC_RADIO3                      1015
#define IDC_Original                    1015
#define IDC_RADIO4                      1016
#define IDC_LAC                         1016
#define IDC_RADIO5                      1017
#define IDC_FDA                         1017
#define IDC_EDIT2                       1018
#define IDC_RATIO                       1018
#define IDC_EDIT3                       1019
#define IDC_STARTINGFROM                1019
#define IDC_GROUP1                      1020
#define IDC_RADIO6                      1021
#define IDC_AsymBoost                   1021
#define ID_TEST_ALL                     32773
#define ID_VIEW_TRAINIMAGE              32774
#define ID_TRAIN                        32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
