void InitTrain(void);
const bool BoostingInputFiles(const bool discard);