#ifndef __IP_H__
#define __IP_H__

#define NUMBER 63000


BOOL BuildModel( void );
void ClassfyImage( unsigned long*, int ,int );

BOOL calcCov( char* );
BOOL DrawVariance( void );


#endif
