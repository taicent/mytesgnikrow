//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by VidCap.rc
//
#define IDD_VIDCAP_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDC_PRV_STATIC                  1000
#define IDC_ADAPTORS_COMBO              1001
#define IDC_ENUMADAPTORS_BUTTON         1002
#define IDC_RUN_BUTTON                  1003
#define IDC_EDIT1                       1004
#define IDC_SAMPLEINTERVAL_EDIT         1004
#define IDC_PRV_STATIC2                 1005
#define IDC_CAPIMG_STATIC               1005
#define IDC_VIDINFO_STATIC              1006
#define IDC_FDETECT_CHECK               1007
#define IDC_CVINFO_STATIC               1008
#define IDC_DETECTIONMS_STATIC          1009

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
