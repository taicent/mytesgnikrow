You need a camera to run this demo.
It works best with a USB camera. The OpenCV 4.0 library seems to have some problems with firewire cameras. The captured video's resolution from a firewire camera is small.

Run the FaceDetect.exe problem, make sure that the camera is plugged in, select 'Test' menu, then the 'Test Live' sub-menu, the video window will capture frames from the camera, and detect faces in them. Don't let the application window cover the video window, otherwise you can not see the result.

Remember to click 'Test->Stop Live Demo' before you close the video window or exit the demo. If you forget to do this, you encounter problems.
