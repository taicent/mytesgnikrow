"""
interfaces package
==================

An umbrella package containing all the interfaces to external packages that Minh-Tri Pham has developed since his Ph.D. time.
"""

# For more help: http://projects.scipy.org/scipy/numpy/wiki/DistutilsDoc
#global_symbols = ['ScipyTest','NumpyTest']
#depends = ['core']
