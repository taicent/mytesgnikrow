"""
interfaces package
==================

An interface to OpenCV from http://wwwx.cs.unc.edu/~gb/wp/blog/2007/02/04/python-opencv-wrapper-using-ctypes/
"""

# For more help: http://projects.scipy.org/scipy/numpy/wiki/DistutilsDoc
#global_symbols = ['ScipyTest','NumpyTest']
#depends = ['core']
