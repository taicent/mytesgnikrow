"""
libraries package
==================

An umbrella package containing all the open-source libraries that Minh-Tri Pham has used for his sdpy package.
"""

# For more help: http://projects.scipy.org/scipy/numpy/wiki/DistutilsDoc
#global_symbols = ['ScipyTest','NumpyTest']
#depends = ['core']
