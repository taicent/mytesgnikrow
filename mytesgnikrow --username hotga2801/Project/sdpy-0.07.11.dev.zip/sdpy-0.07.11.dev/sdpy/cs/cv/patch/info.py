"""
face package
============

An umbrella package containing all packages related to patches (non-object, frontal face, etc) that Minh-Tri Pham has developed since his Ph.D. time.
"""

# For more help: http://projects.scipy.org/scipy/numpy/wiki/DistutilsDoc
#global_symbols = ['ScipyTest','NumpyTest']
#depends = ['core']
