"""
gaussian package
================

An umbrella package containing all packages related to Gaussian distribution assumptions that Minh-Tri Pham has developed since his Ph.D. time.
"""

# For more help: http://projects.scipy.org/scipy/numpy/wiki/DistutilsDoc
#global_symbols = ['ScipyTest','NumpyTest']
#depends = ['core']
