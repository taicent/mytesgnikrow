%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                     ONLINE SUPPORT VECTOR REGRESSION                    %
%                    Copyright 2006 - Francesco Parrella                  %
%                                                                         %
%      This program is distributed under the terms of the GNU License     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% OnlineSVR Examples

% Initializations
clear all;
close all;
clear classes;
 
% Build the OnlineSVR
SVR = OnlineSVR;
 
% Set Parameters
SVR.C = 10;
SVR.Epsilon = 0.1;
SVR.KernelType = 'RBF';
SVR.KernelParam = 30;
SVR.AutoErrorTollerance = true;
SVR.Verbosity = 1;
SVR.StabilizedLearning = true;
SVR.ShowPlots = 1;
SVR.MakeVideo = false;
SVR.VideoTitle = ''; 
 
% Build Training set
TrainingSetX = rand(20,1);
TrainingSetY = sin(TrainingSetX*pi*2);
 
% Training
SVR = SVR.Train(TrainingSetX,TrainingSetY);
 
% Show Info
SVR.ShowInfo;
 
% Predict some values
TestSetX = [0; 1];
TestSetY = sin(TestSetX*pi*2);
PredictedY = SVR.Predict(TestSetX);
Errors = SVR.Margin(TestSetX,TestSetY);
disp(' ');
disp('Some results:');
disp(['f(0)=' num2str(PredictedY(1)) '     y(0)=' num2str(TestSetY(1)) '     margin=' num2str(Errors(1))]);
disp(['f(1)=' num2str(PredictedY(2)) '     y(1)=' num2str(TestSetY(2)) '     margin=' num2str(Errors(2))]);
disp(' ');
 
% Forget first 4 samples
SVR = SVR.Forget(1:4);
 
% Build plot
SVR.BuildPlot;
