%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                     ONLINE SUPPORT VECTOR REGRESSION                    %
%                    Copyright 2006 - Francesco Parrella                  %
%                                                                         %
%      This program is distributed under the terms of the GNU License     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Class SVR - Online Support Vector Regression

class OnlineSVR
    
    properties

        % SVR parameters
        C = 1;                              % Depends 
        Epsilon = 0.1;                      % Error Tollerance
        KernelType = 'Linear';              % Type of Kernel (see Kernel.h for more informations)
        KernelParam = 30;                   % Parameter of the Kernel Function
        KernelParam2 = 0;                   % Parameter of the Kernel Function (for MLP kernel)
        
        % Training Set
        SamplesTrainedNumber = 0;           % Number of samples trained
        X = [];                             % Samples X Matrix (one for each row)
        Y = [];                             % Samples Y Vector
        
        % Weights
        Weights = [];                       % Weights of the support vector machine (one for each sample)
        Bias = 0;                           % Bias of the support vector
        
        % Verbosity
        Verbosity = 1;                      % Verbosity Level (see Verbosity.h for more informations)
        
        % Stabilized Learning
        StabilizedLearning = true;          % If true, stabilize the weights after a training or forgetting

        % Error Tollerance
        AutoErrorTollerance = false;        % Enable or not auto error tollerance
        ErrorTollerance = 0.01;             % Manual Error tollerance
        
        % Display
        ShowPlots = 1;                      % If true, at the end of training/forgetting the svm build an image of the svm
        MakeVideo = 0;                      % If true, it make a video of the training/forgetting process (warning: it's slow)
        VideoTitle = '';                    % Title of the video build if the 'MakeVideo' option is enabled
        FramesNumber = 10;                  % Frames for second used to build the video
        
        % Working Set        
        SupportSetIndexes = [];             % List of indexes of the SupportSet samples
        ErrorSetIndexes = [];               % List of indexes of the ErrorSet samples        
        RemainingSetIndexes = [];           % List of indexes of the RemainingSet samples        
        R = [];                             % R Matrix (contains informations about the support vector samples)        
        
    methods 
    
        % Constructor
        function [SVR] = OnlineSVR(SVR)
        end
    
        % Informations about OnlineSVR
        function [] = display (SVR)
            SVR.ShowUsage;
        end
        
        % Length of the SupportSet
        function [x] = SupportSetElementsNumber (SVR)
            x = length(SVR.SupportSetIndexes);
        end

        % Length of the ErrorSet
        function [x] = ErrorSetElementsNumber (SVR)
            x = length(SVR.ErrorSetIndexes);
        end

        % Length of the RemainingSet
        function [x] = RemainingSetElementsNumber (SVR)
            x = length(SVR.RemainingSetIndexes);
        end

        % Length of the NotSupportSet
        function [x] = NotSupportSetElementsNumber (SVR)
            x = length(SVR.NotSupportSetIndexes);
        end

        % NotSupportSet (ErrorSet + RemainingSet)
        function [x] = NotSupportSetIndexes (SVR)
            x = [SVR.ErrorSetIndexes; SVR.RemainingSetIndexes];
        end

end