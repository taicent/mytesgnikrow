%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                     ONLINE SUPPORT VECTOR REGRESSION                    %
%                    Copyright 2006 - Francesco Parrella                  %
%                                                                         %
%      This program is distributed under the terms of the GNU License     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Show OnlineSVR's Variations

function [] = ShowVariations (SVR, CIndex, H, Beta, Gamma, Lc1, Lc2, Ls, Le, Lr)

    SVR.ShowDetails(CIndex, H);
    
    SVR.ShowMessage('----- VARIATIONS --------------------------------------------------------------------------------------------------------------------',3);    
    SVR.ShowMessage('-------------------------------------------------------------------------------------------------------------------------------------',3);
    Message = sprintf('  ELEMENT \t\tWEIGHTS/H\t\t\t\t\t\t\t\t\tBETA/GAMMA\t\t\t\t\t\t\t\tVARIATION');
    SVR.ShowMessage(Message,3);    
    Message = sprintf('> LC1\t%d\t\t%.30f\t\t%.30f\t\t%.30f',CIndex,H(CIndex),Gamma(CIndex),Lc1);    
    SVR.ShowMessage(Message,3);
    Message = sprintf('> LC2\t%d\t\t%.30f\t\t%.30f\t\t%.30f',CIndex,SVR.Weights(CIndex),0,Lc2);
    SVR.ShowMessage(Message,3);
    for i=1:SVR.SupportSetElementsNumber
        Message = sprintf('> LS%d\t%d\t\t%.30f\t\t%.30f\t\t%.30f',i,SVR.SupportSetIndexes(i),SVR.Weights(SVR.SupportSetIndexes(i)),Beta(i+1),Ls(i));
        SVR.ShowMessage(Message,3);        
    end
    for i=1:SVR.ErrorSetElementsNumber
        Message = sprintf('> LE%d\t%d\t\t%.30f\t\t%.30f\t\t%.30f',i,SVR.ErrorSetIndexes(i),H(SVR.ErrorSetIndexes(i)),Gamma(SVR.ErrorSetIndexes(i)),Le(i));
        SVR.ShowMessage(Message,3);        
    end
    for i=1:SVR.RemainingSetElementsNumber
        Message = sprintf('> LR%d\t%d\t\t%.30f\t\t%.30f\t\t%.30f',i,SVR.RemainingSetIndexes(i),H(SVR.RemainingSetIndexes(i)),Gamma(SVR.RemainingSetIndexes(i)),Lr(i));
        SVR.ShowMessage(Message,3);        
    end
    if (length(Beta)>0)
        Message = sprintf('  TOTAL BETA:\t\t\t\t\t\t\t\t\t\t\t%.30f',sum(Beta(2:size(Beta,1))));
    else
        Message = sprintf('  TOTAL BETA:\t\t\t\t\t\t\t\t\t\t\t%.30f',0);
    end
    SVR.ShowMessage(Message,3);
    SVR.ShowMessage('-------------------------------------------------------------------------------------------------------------------------------------',3);

end