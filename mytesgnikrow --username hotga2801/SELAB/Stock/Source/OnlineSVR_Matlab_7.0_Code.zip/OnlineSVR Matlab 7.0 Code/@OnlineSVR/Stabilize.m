%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                     ONLINE SUPPORT VECTOR REGRESSION                    %
%                    Copyright 2006 - Francesco Parrella                  %
%                                                                         %
%      This program is distributed under the terms of the GNU License     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Stabilize the weigths of an instable OnlineSVR

function [SVR, Flops] = Stabilize (SVR)
    
    % Initialization
    StartTime = clock;
    SVR.ShowMessage('Start Stabilize',1);
    
    % Stabilize Weights
    CurrentSample = 0;
    SamplesToCheck = SVR.SamplesTrainedNumber;
    i = 1;
    Flops = 0;
    while (i<=SamplesToCheck)        
        CurrentSample = CurrentSample + 1;
        if (~SVR.VerifyKKTConditions(i))
            SVR.ShowMessage(' ', 2);
            SVR.ShowMessage(['Stabilizing ' num2str(CurrentSample) '/' num2str(SVR.SamplesTrainedNumber)],1);
            Xc = SVR.X(i,:);
            Yc = SVR.Y(i);
            [SVR, CurrentFlops] = SVR.Unlearn(i);
            Flops = Flops + CurrentFlops;
            [SVR, CurrentFlops] = SVR.Learn(Xc,Yc);            
            Flops = Flops + CurrentFlops;
            SamplesToCheck = SamplesToCheck - 1;
        else
            i =  i + 1;
        end
    end
        
    % Check the final OnlineSVR
    if (~SVR.VerifyKKTConditions)
        disp('OnlineSVR not yet stabilized.');
    end             
    
    % Show execution time
    EndTime = clock;
    StabilizingTime = fix(etime(EndTime,StartTime));    
    SVR.ShowMessage(' ', 2);
    SVR.ShowMessage(['Stabilized the OnlineSVR correctly in ' SVR.TimeToString(StabilizingTime) '.'],1);
    
end