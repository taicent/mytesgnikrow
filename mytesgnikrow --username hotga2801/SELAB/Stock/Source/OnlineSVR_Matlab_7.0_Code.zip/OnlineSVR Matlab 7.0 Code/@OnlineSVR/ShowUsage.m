%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                     ONLINE SUPPORT VECTOR REGRESSION                    %
%                    Copyright 2006 - Francesco Parrella                  %
%                                                                         %
%      This program is distributed under the terms of the GNU License     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Show how to use OnlineSVR

function [] = ShowUsage (SVR)

    % Usage
    disp (' ');
    disp ('Usage:   SVR = OnlineSVR;');

    % OnlineSVR Attributes
    disp (' ');    
    disp ('OnlineSVR Attributes:');
    disp('> SVR.Epsilon                         Epsilon Parameter (Default:0.1)');
    disp('> SVR.C                               C Parameter (Default:1)');
    disp('> SVR.KernelType                      Type of Kernel (Default:RBF)');
    disp('> SVR.KernelParam                     Kernel Function Parameter (Default:30)');
    disp('> SVR.KernelParam2                    Kernel Function Parameter2 (Default:0)');
    disp('> AutoErrorTollerance                 Enable  auto error tollerance (Default:true)');
    disp('> ErrorTollerance                     Error Tollerance Parameter (Default:Epsilon/10)');
    disp('> StabilizedLearning                  Correct errors of training (Default:true)');
    
    % Video Attributes
    disp (' ');
    disp ('Video Attributes:');
    disp ('> SVR.ShowPlots                      Shows OnlineSVR plots during trainings (Default:true)');
    disp ('> SVR.MakeVideo                      Make a training video (Default:false)');
    disp ('> SVR.VideoTitle                     Video Title');
    disp ('> SVR.FramesNumber                   Frames per second (Default:10)');
    
    % Other Attributes
    disp (' ');
    disp ('Other Attributes:');
    disp ('> SVR.X                              Training Set X');
    disp ('> SVR.Y                              Training Set Y');
    disp ('> SVR.Weights                        Training Set Weigths');
    disp ('> SVR.Bias                           Bias');
    disp ('> SVR.SupportSetIndexes              Support Set Indexes');
    disp ('> SVR.ErrorSetIndexes                Error Set Indexes');
    disp ('> SVR.RemainingSetIndexes            Remaining Set Indexes');
    disp ('> SVR.SamplesTrainedNumber           Samples Trained Number');
    disp ('> SVR.SupportSetElementsNumber       Support Samples Number');
    disp ('> SVR.ErrorSetElementsNumber         Error Samples Number');
    disp ('> SVR.RemainingSetElementsNumber     Remaining Samples Number');
    
    % OnlineSVR Methods
    disp (' ');
    disp ('OnlineSVR Methods:');
    disp ('SVR.Train(X,Y)                       Train samples (X,Y)');
    disp ('SVR.Forget(Indexes)                  Forget samples');
    disp ('SVR.Stabilize()                      Stabilize OnlineSVR');
    disp ('SVR.Predict(X)                       Predict Y values of X');
    disp ('SVR.Margin(X,Y)                      Predict values of X and subtract it to Y');
    disp ('SVR.VerifyKKYConditions()            Returns true if KKT conditions are verified');
    
    % Plot Methods
    disp (' ');
    disp ('Plot Methods:');
    disp ('SVR.BuildPlot                        Build plot of current OnlineSVR');    
    
    % I/O Methods
    disp (' ');
    disp ('Other Methods:');
    disp ('SVR.ShowInfo                         Show Info about current OnlineSVR');    
    disp ('SVR.ShowDetails                      Show Details about current OnlineSVR');    
    disp (' ');
        
end