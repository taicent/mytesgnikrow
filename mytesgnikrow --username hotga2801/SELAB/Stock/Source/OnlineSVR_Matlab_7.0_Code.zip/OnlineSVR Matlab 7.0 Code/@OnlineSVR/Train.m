%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                     ONLINE SUPPORT VECTOR REGRESSION                    %
%                    Copyright 2006 - Francesco Parrella                  %
%                                                                         %
%      This program is distributed under the terms of the GNU License     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Train the OnlineSVR with new data

function [SVR, Flops] = Train (SVR, NewSamplesX, NewSamplesY)    

    % Inizialization
    SamplesNumber = size(NewSamplesX,1);
    StartTime = clock;
        
    % Make the video
    if (SVR.MakeVideo)
        if (exist('Temporary OnlineSVR Files'))
            rmdir('Temporary OnlineSVR Files','s');
        end
        mkdir('Temporary OnlineSVR Files');
        SVR.FramesNumber = 0;
    end
    
    % Continue the training
    SVR.ShowMessage('Start Training...',1);
    Flops = 0;
    for i=1:SamplesNumber
        
        % Check if the sample is already added
        Index = SVR.INDEXOF(SVR.X, NewSamplesX(i,:));
        if (Index>0 && SVR.Y(Index)==NewSampleY(i))
            continue;
        end
        
        % Train a new sample
        SVR.ShowMessage(' ', 2);
        SVR.ShowMessage(['Training ' num2str(i) '/' num2str(SamplesNumber)], 1); 
        [SVR, CurrentFlops] = SVR.Learn(NewSamplesX(i,:), NewSamplesY(i));  
        Flops = Flops + CurrentFlops;
        Iterations(i) = Flops;
        % Show the plot
        if (SVR.MakeVideo>0)
            SVR = SVR.BuildPlot;
        end
    end
    save 'Iterations.txt' 'Iterations' -ASCII -DOUBLE -TABS;

    % Stabilized Learning
    if (SVR.StabilizedLearning)
        StabilizationsNumber = 0;
        while (~SVR.VerifyKKTConditions)
            [SVR, CurrentFlops] = SVR.Stabilize();
            Flops = Flops + CurrentFlops;
            StabilizationsNumber = StabilizationsNumber + 1;
            if (StabilizationsNumber > SVR.SamplesTrainedNumber)
                disp(['It''s impossible to stabilize the OnlineSVR. Please add or remove some new samples.']);
                break;
            end
        end
    end
    
    % Show execution time
    EndTime = clock;
    LearningTime = fix(etime(EndTime,StartTime));
    SVR.ShowMessage(' ',2);
    SVR.ShowMessage(['Trained ' num2str(SamplesNumber) ' elements correctly in ' SVR.TimeToString(LearningTime) '.'],1);
    
    % Build the video
    if (SVR.MakeVideo)
        SVR.BuildVideo;
        rmdir('Temporary OnlineSVR Files','s');
    end
    
end
