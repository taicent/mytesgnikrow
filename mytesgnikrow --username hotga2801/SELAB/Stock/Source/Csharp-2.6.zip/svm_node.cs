using System;
namespace libsvm
{
	[Serializable]
	public class svm_node
	{
		public int index;
		public double value_Renamed;
	}
}